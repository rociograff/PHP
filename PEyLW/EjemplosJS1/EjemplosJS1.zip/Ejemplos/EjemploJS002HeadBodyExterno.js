function enExterno(){
	alert("en Externo");
	}